package com.example.button

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.constraintlayout.widget.ConstraintLayout
import java.util.*
import kotlin.random.Random.Default.nextInt

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val myButton: Button=findViewById(R.id.button)
        myButton.setOnClickListener {
            val layout=findViewById<ConstraintLayout>(R.id.mainlayout)
            //layout.setBackgroundColor(resources.getColor(R.color.Medium_Aquamarine))
            myButton.text="Dineer is a HOE"
            val rnd=Random()
            val color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256))
            layout.setBackgroundColor(color)
        }
        val counter= 0
    }
}