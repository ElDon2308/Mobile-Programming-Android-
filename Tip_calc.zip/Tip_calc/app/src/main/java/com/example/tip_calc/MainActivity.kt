package com.example.tip_calc

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.constraintlayout.widget.ConstraintLayout

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
/*
    fun TipCalc(view: View)
    {
        var myButton:Button=findViewById<Button>(R.id.button)
        var myButton2:Button=findViewById<Button>(R.id.button2)
        var myButton3:Button=findViewById<Button>(R.id.button3)
        var amt_input:EditText=findViewById<EditText>(R.id.Amount)

        //recognizes button as a bill
        var buttonPressed = view as Button

        //passes in Amount(edit text view)
        var bill_amt:EditText=findViewById(R.id.Amount)

        // From now on use text(it is the same as .getText()
        //Turns whatever bill_amt is into a double
        var amt= bill_amt.text.toString().toDouble()

        //Initialized tip amt var
        var tip_amt= 0

        //If statements to control each button
        if(buttonPressed.id.equals(R.id.button))
        {
            //changes back ground color of button when tapped
            myButton.setBackgroundColor(Color.CYAN)

            //Denotes that the button was pressed
            buttonPressed.text="15% Selected!"

            //type casts tip_amt to a double to calc the tip
            var tip_amt:Double= amt * .15

            //takes the total of amt and tip_amt
            var total_amt = tip_amt + amt

            //selects textView2 for the output and shows the output
            var myTotal:TextView=findViewById(R.id.textView2)
            myTotal.text="$total_amt The tip amount is $tip_amt"
        }

        if(buttonPressed.id.equals(R.id.button2))
        {
            myButton2.setBackgroundColor(Color.CYAN)
            buttonPressed.text="20% Selected!"
            var tip_amt:Double= amt * .20
            var total_amt = tip_amt + amt
            var myTotal:TextView=findViewById(R.id.textView2)
            myTotal.text="$total_amt The tip amount is $tip_amt"
        }

        if(buttonPressed.id.equals(R.id.button3))
        {
            myButton3.setBackgroundColor(Color.CYAN)
            buttonPressed.text="25% Selected!"
            var tip_amt:Double= amt * .25
            var total_amt = tip_amt + amt
            var myTotal:TextView=findViewById(R.id.textView2)
            myTotal.text="$total_amt The tip amount is $tip_amt"
        }
        //Give a toast message
        Toast.makeText(getApplicationContext(),"You have paid!", Toast.LENGTH_SHORT).show();

    }
*/
        //This is they way I learned with some practice last night with some other classmates

    fun TipCalc(view: View)
    {
        val fifteen:Button=findViewById<Button>(R.id.button)
        fifteen.text="15% Selected!"

        var user_input:EditText=findViewById<EditText>(R.id.Amount)

        var amt= user_input.getText().toString().toDouble()

        var math1= amt * .15

        var total= amt + math1
        val myMath:TextView=findViewById<TextView>(R.id.textView2)
        myMath.text="$total The tip amount was $math1"
        Toast.makeText(getApplicationContext(),"You have paid!", Toast.LENGTH_SHORT).show();
    }

    fun TipCalc2(view: View)
    {
        val twenty:Button=findViewById<Button>(R.id.button2)
        twenty.text="20% Selected!"

        var user_input:EditText=findViewById<EditText>(R.id.Amount)

        var amt= user_input.getText().toString().toDouble()

        var math= amt * .20

        var total= amt + math
        val myMath:TextView=findViewById<TextView>(R.id.textView2)
        myMath.text="$total The tip amount was $math"
        Toast.makeText(getApplicationContext(),"You have paid!", Toast.LENGTH_SHORT).show();
    }

    fun TipCalc3(view: View)
    {
        val twentyFive:Button=findViewById<Button>(R.id.button3)
        twentyFive.text="25% Selected!"

        var user_input:EditText=findViewById<EditText>(R.id.Amount)

        var amt= user_input.getText().toString().toDouble()

        var math1= amt * .25

        var total= amt + math1
        val myMath:TextView=findViewById<TextView>(R.id.textView2)
        myMath.text="$total The tip amount was $math1"
        Toast.makeText(getApplicationContext(),"You have paid!", Toast.LENGTH_SHORT).show();
    }

}