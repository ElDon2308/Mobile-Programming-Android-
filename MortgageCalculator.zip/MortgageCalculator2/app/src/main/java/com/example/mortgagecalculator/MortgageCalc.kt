package com.example.mortgagecalculator

import kotlin.math.pow

class MortgageCalc(var rate:Double, var years:Int, var principal:Double ) {
    fun rateCalc():Double{
        var r=(rate/100/12)
        return r
    }

    fun loanOut(): Double {
        var loan = principal
        return loan
    }

    fun p_nums():Int{
        var numPayments= years*12
        return numPayments
    }

    fun monthlyPayments():Double{
        //
        var payments=  loanOut()* (rateCalc()*(1+rateCalc()).pow(p_nums()))/((1+rateCalc()).pow(p_nums())-1)
        return payments
    }

    fun total_pay(): Double {
        var tp= (p_nums() *12)*monthlyPayments()-loanOut()
        return tp
    }
}