package com.example.mortgagecalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import java.text.DecimalFormat

class Activity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_2)
        var df = DecimalFormat("$#.##")
        var rf= DecimalFormat("$#.########")

        MainActivity.mInfo

        var p_text: TextView = findViewById(R.id.pOut)
        var r_text: TextView = findViewById(R.id.rOut)
        var m_text: TextView = findViewById(R.id.Monthly)
        var numberPays:TextView= findViewById(R.id.payment_num)
        var total_mPays:TextView= findViewById(R.id.total)


        p_text.text = "Your loan is ${df.format(MainActivity.mCal.loanOut())}"
        r_text.text = "Your rate is ${rf.format(MainActivity.mCal.rateCalc())}"
        m_text.text = "Your monthly payments are ${df.format(MainActivity.mCal.monthlyPayments())}"
        numberPays.text= "You have ${MainActivity.mCal.p_nums()} payments!"
        total_mPays.text= "Your total payment is ${df.format(MainActivity.mCal.total_pay())}"

    }
    fun returnToActOne(view: View) {
        this.finish()
    }
}