package com.example.mortgagecalculator

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    companion object mInfo{
        lateinit var mCal:MortgageCalc
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun Mcalculator(view: View) {
        var u_principal:EditText=findViewById(R.id.pricipal_amount)
        var u_rate:EditText=findViewById(R.id.Interes)
        var u_num_payments:EditText=findViewById(R.id.num_payments)


        //convert user inputs
        var p = u_principal.text.toString().toDouble()
        var r = u_rate.text.toString().toDouble()
        var y = u_num_payments.text.toString().toInt()

        mCal= MortgageCalc(r,y,p)

        val myIntent=Intent(this,Activity2::class.java)
        this.startActivity(myIntent)

    }


}