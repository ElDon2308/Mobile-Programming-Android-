package com.example.tip_calc

import android.graphics.Color
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity


open class bill
{
    var total:Double=0.00
    var tip_amt:Double=0.00
    constructor(total:Double , tip_amt:Double)
    {
        this.total=total
        this.tip_amt=tip_amt

    }
    fun tip_calc():Double
    {
        var tip=tip_amt *total
        return tip
    }

    fun total_bill_amt():Double
    {
         var amount=tip_calc() + total
        return amount
    }
}