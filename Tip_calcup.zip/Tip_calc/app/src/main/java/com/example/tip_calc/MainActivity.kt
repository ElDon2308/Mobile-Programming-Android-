package com.example.tip_calc

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.constraintlayout.widget.ConstraintLayout

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun TipCalc(view: View) {
        //Selects the buttons viewa
        var myButton: Button = findViewById<Button>(R.id.button)
        var myButton2: Button = findViewById<Button>(R.id.button2)
        var myButton3: Button = findViewById<Button>(R.id.button3)


        //recognizes button has been pressed
        var buttonPressed = view as Button

        //passes in Amount(edit text view)
        var bill_amt: EditText = findViewById(R.id.Amount)

        // From now on use text(it is the same as .getText()
        //Turns whatever bill_amt is into a double
        var amt = bill_amt.text.toString().toDouble()
        //passes in parameters for the bill class
        var input = bill(amt, .15)

        //Initialized tip amt var
        var tip_amt = 0

        //If statements to control each button
        if (buttonPressed.id.equals(R.id.button)) {
            var input = bill(amt, .15)
            //changes back ground color of button when tapped
            myButton.setBackgroundColor(Color.CYAN)

            //Denotes that the button was pressed
            buttonPressed.text = "15% Selected!"

            //takes the total of amt and tip_amt
            var total_amt = tip_amt + amt

            //selects textView2 for the output and shows the output
            var myTotal: TextView = findViewById(R.id.textView2)
            myTotal.text ="This is tip $ ${input.tip_calc()} and here is the total $${input.total_bill_amt()}"
        }

        if (buttonPressed.id.equals(R.id.button2)) {
            var input = bill(amt, .20)
            //changes back ground color of button when tapped
            myButton2.setBackgroundColor(Color.CYAN)

            //Denotes that the button was pressed
            buttonPressed.text = "20% Selected!"

            //takes the total of amt and tip_amt
            var total_amt = tip_amt + amt

            //selects textView2 for the output and shows the output
            var myTotal: TextView = findViewById(R.id.textView2)
            myTotal.text =
                "This is tip $ ${input.tip_calc()} and here is the total $${input.total_bill_amt()}"
        }

        if (buttonPressed.id.equals(R.id.button3)) {
            var input = bill(amt, .25)
            //changes back ground color of button when tapped
            myButton3.setBackgroundColor(Color.CYAN)

            //Denotes that the button was pressed
            buttonPressed.text = "25% Selected!"

            //takes the total of amt and tip_amt
            var total_amt = tip_amt + amt

            //selects textView2 for the output and shows the output
            var myTotal: TextView = findViewById(R.id.textView2)
            myTotal.text =
                "This is tip $${input.tip_calc()} and here is the total $${input.total_bill_amt()}"
        }
    }
}