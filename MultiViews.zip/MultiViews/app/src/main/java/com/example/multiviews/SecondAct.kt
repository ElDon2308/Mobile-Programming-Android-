package com.example.multiviews

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast

class SecondAct : AppCompatActivity() {
    companion object myCobj{
        var myString= ""
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)
        val nameFromFirst= getIntent().getStringExtra("Name")
        val myText:TextView=findViewById(R.id.Name)
        myText.text= nameFromFirst
        Toast.makeText(this, nameFromFirst, Toast.LENGTH_LONG).show()
        myCobj.myString= "Pat here you go!"
    }

    override fun onPause() {
        super.onPause()
        getIntent().putExtra("Example","Here is the message from Act 2")
    }
    fun returnToActOne(view: View) {

        this.finish()
    }

}