package com.example.multiviews

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
    fun activiySwitch(view: View) {
        //crate an instance of the second act and launch it
        val myIntent=Intent(this,SecondAct::class.java)
        val name=findViewById<EditText>(R.id.UserName)
        myIntent.putExtra("Name",name.text.toString())
        this@MainActivity.startActivity(myIntent)
    }

    override fun onResume() {
        super.onResume()
        val name=findViewById<TextView>(R.id.message)
        var mesg=SecondAct.myCobj.myString
        name.text=mesg
    }
}