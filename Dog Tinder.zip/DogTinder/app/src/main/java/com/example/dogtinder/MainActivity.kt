package com.example.dogtinder


import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.widget.Toast


class MainActivity : AppCompatActivity(), GestureDetector.OnGestureListener{
    private lateinit var myDetector: GestureDetector
    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        myDetector= GestureDetector(this,this)
        Toast.makeText(this,"PROGRAM RUNNING!", Toast.LENGTH_SHORT).show()
    }
    var count=0
    override fun onTouchEvent(event: MotionEvent?): Boolean {
        myDetector.onTouchEvent(event)
        return super.onTouchEvent(event)
    }
    override fun onDown(p0: MotionEvent?): Boolean {
        return true
    }

    override fun onShowPress(p0: MotionEvent?) {
        return
    }

    override fun onSingleTapUp(p0: MotionEvent?): Boolean {
        return true
    }

    override fun onScroll(p0: MotionEvent?, p1: MotionEvent?, p2: Float, p3: Float): Boolean {
        return true
    }

    override fun onLongPress(p0: MotionEvent?) {
        return
    }

    override fun onFling(p0: MotionEvent?, p1: MotionEvent?, X: Float, Y: Float): Boolean {
        val c:View=findViewById(R.id.main_lay)
        if (X > 0) {
            Log.d("Motion", "SWIPE RIGHT DETECTED:$X $Y ")
            count++
            if (count > 7) {
                count =7
            }
            if (count == 2) {
                c.setBackgroundColor(Color.rgb(255, 165, 0))
            }
            if (count == 3) {
                c.setBackgroundColor(Color.rgb(255, 255, 0))
            }
            if (count == 4) {
                c.setBackgroundColor(Color.rgb(0, 255, 0))
            }
            if(count==5){
                c.setBackgroundColor(Color.rgb(0, 0, 255))
            }
            if(count==6){
                c.setBackgroundColor(Color.rgb(75, 0, 130))
            }
            if(count==7){
                c.setBackgroundColor(Color.rgb(148, 0, 211))
            }
        } else if (X < 0) {
            Log.d("Motion", "SWIPE LEFT DETECTED: $X $Y")
            count--
            if (count < 1) {
                count =1
            }
            if (count == 1) {
                c.setBackgroundColor(Color.rgb(255,0,0))
            }
            if (count == 2) {
                c.setBackgroundColor(Color.rgb(255, 165, 0))
            }
            if (count == 3) {
                c.setBackgroundColor(Color.rgb(255, 255, 0))
            }
            if (count == 4) {
                c.setBackgroundColor(Color.rgb(0, 255, 0))
            }
            if(count==5){
                c.setBackgroundColor(Color.rgb(0, 0, 255))
            }
            if(count==6){
                c.setBackgroundColor(Color.rgb(75, 0, 130))
            }
            if(count==7){
                c.setBackgroundColor(Color.rgb(148, 0, 211))
            }
        }
        return true
    }
}
